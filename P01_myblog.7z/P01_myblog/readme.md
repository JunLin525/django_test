# 我的django程式學習
## 台大課程來學習
就這樣學習的狀況中
- 特色用於處理django
- 希望可以好好處理

```
django-admin startproject myblog
cd myblog
python manage.py startapp mainstie
python manage.py runserver
``` 

點擊網站:  
<http://127.0.0.1:8000>